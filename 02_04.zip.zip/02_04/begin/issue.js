const queue = '[{"id":"394","title":"Eat your veggies"},{"id":"378","title":"Every step counts"},{"id":"406","title":"Giving Back"}]';

// Enter code to destringify the `queue` variable here:
const queueDes = JSON.parse(queue);

const item = '{"id":"406","title":"Giving Back"}';

// Enter code to destringify the `item` variable here:
const itemDes = JSON.parse(item);
